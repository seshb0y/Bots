"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// index.ts
const dotenv_1 = require("dotenv");
const bot_1 = require("./bot");
const commands_1 = require("./commands");
const logger_1 = require("./utils/logger");
(0, dotenv_1.config)();
// Настройка команд
(0, commands_1.setupCommands)(bot_1.client);
// Обработка ошибок процесса
process.on("unhandledRejection", (reason, promise) => {
    (0, logger_1.error)("Необработанное отклонение промиса", { reason, promise });
});
process.on("uncaughtException", (err) => {
    (0, logger_1.error)("Необработанное исключение", err);
});
// Запуск бота
bot_1.client.login(process.env.DISCORD_TOKEN).then(() => {
    (0, logger_1.info)("Бот успешно подключился к Discord");
}).catch((err) => {
    (0, logger_1.error)("Ошибка при подключении к Discord", err);
});
