"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalize = normalize;
function normalize(str) {
    return str.toLowerCase().replace(/\s+/g, "");
}
