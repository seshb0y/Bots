"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogLevel = void 0;
exports.log = log;
exports.debug = debug;
exports.info = info;
exports.warn = warn;
exports.error = error;
exports.logVoiceState = logVoiceState;
exports.logStats = logStats;
exports.logSyncclan = logSyncclan;
exports.logPbNotify = logPbNotify;
exports.logQueue = logQueue;
exports.logReward = logReward;
exports.logCommand = logCommand;
exports.logInteraction = logInteraction;
exports.logError = logError;
exports.cleanupOldLogs = cleanupOldLogs;
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const LOG_DIR = path.join(__dirname, "..", "..", "logs");
const LOG_FILE = path.join(LOG_DIR, `bot-${new Date().toISOString().slice(0, 10)}.log`);
// Создаем папку для логов если её нет
if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
}
var LogLevel;
(function (LogLevel) {
    LogLevel["DEBUG"] = "DEBUG";
    LogLevel["INFO"] = "INFO";
    LogLevel["WARN"] = "WARN";
    LogLevel["ERROR"] = "ERROR";
})(LogLevel || (exports.LogLevel = LogLevel = {}));
function getTimestamp() {
    return new Date().toISOString().replace('T', ' ').slice(0, 19);
}
function formatMessage(level, message, data) {
    const timestamp = getTimestamp();
    const dataStr = data ? ` | ${JSON.stringify(data)}` : '';
    return `[${timestamp}] [${level}] ${message}${dataStr}`;
}
function writeToFile(message) {
    try {
        fs.appendFileSync(LOG_FILE, message + '\n', 'utf-8');
    }
    catch (error) {
        console.error('Ошибка записи в лог файл:', error);
    }
}
function log(level, message, data) {
    const formattedMessage = formatMessage(level, message, data);
    // Записываем в файл
    writeToFile(formattedMessage);
    // Выводим в консоль с цветами
    const colors = {
        [LogLevel.DEBUG]: '\x1b[36m', // Cyan
        [LogLevel.INFO]: '\x1b[32m', // Green
        [LogLevel.WARN]: '\x1b[33m', // Yellow
        [LogLevel.ERROR]: '\x1b[31m', // Red
    };
    const reset = '\x1b[0m';
    console.log(`${colors[level]}${formattedMessage}${reset}`);
}
function debug(message, data) {
    log(LogLevel.DEBUG, message, data);
}
function info(message, data) {
    log(LogLevel.INFO, message, data);
}
function warn(message, data) {
    log(LogLevel.WARN, message, data);
}
function error(message, data) {
    log(LogLevel.ERROR, message, data);
}
// Специальные функции для разных компонентов бота
function logVoiceState(message, data) {
    log(LogLevel.INFO, `[VOICE] ${message}`, data);
}
function logStats(message, data) {
    log(LogLevel.INFO, `[STATS] ${message}`, data);
}
function logSyncclan(message, data) {
    log(LogLevel.INFO, `[SYNCCLAN] ${message}`, data);
}
function logPbNotify(message, data) {
    log(LogLevel.INFO, `[PB_NOTIFY] ${message}`, data);
}
function logQueue(message, data) {
    log(LogLevel.INFO, `[QUEUE] ${message}`, data);
}
function logReward(message, data) {
    log(LogLevel.INFO, `[REWARD] ${message}`, data);
}
function logCommand(message, data) {
    log(LogLevel.INFO, `[COMMAND] ${message}`, data);
}
function logInteraction(message, data) {
    log(LogLevel.INFO, `[INTERACTION] ${message}`, data);
}
function logError(message, error) {
    log(LogLevel.ERROR, `[ERROR] ${message}`, error);
}
// Функция для очистки старых логов (оставляем только за последние 30 дней)
function cleanupOldLogs() {
    try {
        const files = fs.readdirSync(LOG_DIR);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        for (const file of files) {
            if (file.startsWith('bot-') && file.endsWith('.log')) {
                const filePath = path.join(LOG_DIR, file);
                const stats = fs.statSync(filePath);
                if (stats.mtime < thirtyDaysAgo) {
                    fs.unlinkSync(filePath);
                    info(`Удален старый лог файл: ${file}`);
                }
            }
        }
    }
    catch (error) {
        logError('Ошибка при очистке старых логов', error);
    }
}
