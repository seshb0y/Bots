"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const discord_js_1 = require("discord.js");
require("dotenv/config");
const commands = [
    new discord_js_1.SlashCommandBuilder()
        .setName("help")
        .setDescription("Показать список всех команд"),
    new discord_js_1.SlashCommandBuilder().setName("ping").setDescription("Проверка бота"),
    new discord_js_1.SlashCommandBuilder()
        .setName("points")
        .setDescription("Посмотреть свои очки"),
    new discord_js_1.SlashCommandBuilder()
        .setName("addtracer")
        .setDescription("Добавить игрока в отслеживание")
        .addStringOption((option) => option
        .setName("nickname")
        .setDescription("Никнейм игрока в War Thunder")
        .setRequired(true)),
    new discord_js_1.SlashCommandBuilder()
        .setName("removetracer")
        .setDescription("Удалить игрока из отслеживания")
        .addStringOption((option) => option
        .setName("nickname")
        .setDescription("Никнейм игрока в War Thunder")
        .setRequired(true)),
    new discord_js_1.SlashCommandBuilder()
        .setName("listtraced")
        .setDescription("Список отслеживаемых игроков"),
    new discord_js_1.SlashCommandBuilder()
        .setName("syncclan")
        .setDescription("Синхронизировать очки участников по клану")
        .addStringOption((option) => option
        .setName("clan")
        .setDescription("Тег клана (например, ALLIANCE)")
        .setRequired(true)),
    new discord_js_1.SlashCommandBuilder()
        .setName("resettleavers")
        .setDescription("Сбросить файл отслеживания покинувших игроков"),
    new discord_js_1.SlashCommandBuilder()
        .setName("pbnotify")
        .setDescription("Manually send PB notification to officers"),
    new discord_js_1.SlashCommandBuilder()
        .setName("resources")
        .setDescription("Show current CPU and memory usage of the bot")
        .addStringOption((option) => option
        .setName("option")
        .setDescription("Выберите режим")
        .setRequired(false)
        .addChoices({ name: "current", value: "current" }, { name: "history", value: "history" })),
    new discord_js_1.SlashCommandBuilder()
        .setName("checktracked")
        .setDescription("Manually check tracked players and notify officers if needed"),
    new discord_js_1.SlashCommandBuilder()
        .setName("stats")
        .setDescription("Показать статистику изменений очков за сутки по игрокам"),
    new discord_js_1.SlashCommandBuilder()
        .setName("teststats")
        .setDescription("Тестовая команда для проверки статистики с лидербордом"),
    new discord_js_1.SlashCommandBuilder()
        .setName("simpletest")
        .setDescription("Простая тестовая команда"),
].map((cmd) => cmd.toJSON());
const rest = new discord_js_1.REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
async function registerCommands() {
    try {
        console.log("🔁 Регистрируем команды...");
        await rest.put(discord_js_1.Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID), { body: commands });
        console.log("✅ Команды успешно зарегистрированы");
    }
    catch (err) {
        console.error("❌ Ошибка при регистрации:", err);
    }
}
registerCommands();
