"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.voiceCounts = exports.client = void 0;
const discord_js_1 = require("discord.js");
const dotenv_1 = require("dotenv");
const constants_1 = require("./constants");
const json_1 = require("./utils/json");
const pbNotify_1 = require("./utils/pbNotify");
const clan_1 = require("./utils/clan");
const leaderboard_1 = require("./utils/leaderboard");
const normalize_1 = require("./utils/normalize");
const resources_1 = require("./commands/resources");
const logger_1 = require("./utils/logger");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
(0, dotenv_1.config)();
const client = new discord_js_1.Client({
    intents: [
        discord_js_1.GatewayIntentBits.Guilds,
        discord_js_1.GatewayIntentBits.GuildVoiceStates,
        discord_js_1.GatewayIntentBits.GuildMessages,
        discord_js_1.GatewayIntentBits.MessageContent,
        discord_js_1.GatewayIntentBits.GuildMembers,
    ],
});
exports.client = client;
const voiceCounts = new Map();
exports.voiceCounts = voiceCounts;
const QUEUE_NICKNAME_EXCLUDE_IDS = [
    '642764542266310658', // ID владельца сервера
];
// --- Очередь для канала "замена на полковые бои" ---
const QUEUE_CHANNEL_ID = "821082995188170783";
// В памяти: userId -> оригинальный ник
const originalNicknames = {};
// Очередь: userId[] — порядок участников
let queueOrder = [];
const emojiNumbers = [
    "1️⃣",
    "2️⃣",
    "3️⃣",
    "4️⃣",
    "5️⃣",
    "6️⃣",
    "7️⃣",
    "8️⃣",
    "9️⃣",
    "🔟",
];
function stripEmojiNumber(nick) {
    return nick.replace(/^(1️⃣|2️⃣|3️⃣|4️⃣|5️⃣|6️⃣|7️⃣|8️⃣|9️⃣|🔟)\s*/, "").trim();
}
async function updateQueueNicknames(guild, members) {
    const startTime = Date.now();
    for (let i = 0; i < queueOrder.length; i++) {
        const userId = queueOrder[i];
        const member = members.find(m => m.id === userId);
        if (!member)
            continue;
        const orig = originalNicknames[userId] || stripEmojiNumber(member.nickname || member.user.username);
        originalNicknames[userId] = orig;
        const num = i < emojiNumbers.length ? emojiNumbers[i] : (i + 1).toString();
        const newNick = `${num} ${orig}`;
        if (QUEUE_NICKNAME_EXCLUDE_IDS.includes(userId)) {
            // Не меняем ник, но логируем
            (0, logger_1.logQueue)(`(Исключение) Не меняем ник для ${orig} (ID: ${userId}), но учитываем в очереди как номер ${num}`);
            continue;
        }
        if (member.nickname !== newNick) {
            try {
                await member.setNickname(newNick, "Обновление очереди на полковые бои");
            }
            catch (e) {
                (0, logger_1.logQueue)(`Не удалось изменить ник ${orig}`, e);
            }
        }
        (0, logger_1.logQueue)(`${num} ${orig} (ID: ${member.id})`);
    }
    // Итоговый порядок очереди
    (0, logger_1.logQueue)("Итоговый порядок очереди:");
    for (let i = 0; i < queueOrder.length; i++) {
        const userId = queueOrder[i];
        const member = members.find((m) => m.id === userId);
        if (!member)
            continue;
        const orig = originalNicknames[userId];
        const num = i < emojiNumbers.length ? emojiNumbers[i] : (i + 1).toString();
        (0, logger_1.logQueue)(`${num} ${orig} (ID: ${member.id})`);
    }
    (0, resources_1.trackFunctionPerformance)('updateQueueNicknames', startTime);
}
async function removeQueueNumber(member) {
    if (!member)
        return;
    const orig = originalNicknames[member.id] ||
        stripEmojiNumber(member.nickname || member.user.username);
    if (member.nickname !== orig) {
        try {
            await member.setNickname(orig, "Выход из очереди на полковые бои");
        }
        catch (e) {
            (0, logger_1.logQueue)(`Не удалось вернуть ник ${orig}`, e);
        }
    }
    delete originalNicknames[member.id];
}
let lastQueueIds = [];
client.on("voiceStateUpdate", async (oldState, newState) => {
    const startTime = Date.now();
    const oldChannelId = oldState.channelId;
    const newChannelId = newState.channelId;
    const guild = oldState.guild || newState.guild;
    // Работаем только с очередным каналом
    if (oldChannelId === QUEUE_CHANNEL_ID || newChannelId === QUEUE_CHANNEL_ID) {
        // Получаем актуальных участников канала
        const channel = await guild.channels.fetch(QUEUE_CHANNEL_ID);
        const members = channel && channel.isVoiceBased()
            ? Array.from(channel.members.values())
                .map((m) => m)
                .filter((m) => !m.user.bot)
            : [];
        const currentIds = members.map((m) => m.id);
        // Проверяем, изменился ли состав очереди
        const changed = currentIds.length !== lastQueueIds.length ||
            currentIds.some((id, i) => id !== lastQueueIds[i]);
        if (!changed) {
            // Состав не изменился — не обновляем никнеймы
            (0, resources_1.trackFunctionPerformance)('voiceStateUpdate_skipped', startTime);
            return;
        }
        // Если канал пуст — сбрасываем очередь
        if (members.length === 0) {
            // Если кто-то только что вышел — вернуть ему ник
            if (oldChannelId === QUEUE_CHANNEL_ID &&
                newChannelId !== QUEUE_CHANNEL_ID &&
                oldState.member) {
                await removeQueueNumber(oldState.member);
            }
            queueOrder = [];
            for (const id of Object.keys(originalNicknames))
                delete originalNicknames[id];
            (0, logger_1.logQueue)("Очередь сброшена (канал пуст)");
            (0, resources_1.trackFunctionPerformance)('voiceStateUpdate_empty', startTime);
            return;
        }
        // Удаляем из очереди тех, кого нет в канале
        queueOrder = queueOrder.filter((id) => currentIds.includes(id));
        // Добавляем новых в конец очереди
        for (const m of members) {
            if (!queueOrder.includes(m.id)) {
                queueOrder.push(m.id);
                // Сохраняем оригинальный ник без emoji-номера
                originalNicknames[m.id] = stripEmojiNumber(m.nickname || m.user.username);
            }
        }
        // Если кто-то вышел — снимаем номер
        if (oldChannelId === QUEUE_CHANNEL_ID &&
            newChannelId !== QUEUE_CHANNEL_ID &&
            oldState.member) {
            await removeQueueNumber(oldState.member);
        }
        await updateQueueNicknames(guild, members);
        lastQueueIds = [...currentIds];
    }
    // ... существующая логика обновления voiceCounts ...
    for (const channelId of [oldChannelId, newChannelId]) {
        if (!channelId)
            continue;
        try {
            const channel = await guild.channels.fetch(channelId);
            if (channel?.isVoiceBased()) {
                const realCount = Array.from(channel.members.values()).filter((m) => !m.user.bot).length;
                const prev = voiceCounts.get(channelId);
                voiceCounts.set(channelId, realCount);
                if (prev !== realCount) {
                    (0, logger_1.logVoiceState)(`Канал "${channel.name}" обновлён: было ${prev ?? "?"}, стало ${realCount}`);
                }
            }
        }
        catch (err) {
            (0, logger_1.error)(`Не удалось обновить канал ${channelId}`, err);
        }
    }
    (0, resources_1.trackFunctionPerformance)('voiceStateUpdate', startTime);
});
function getNextStatsDelayMs() {
    // Используем московское время (UTC+3)
    const now = new Date();
    const mskHour = now.getUTCHours() + 3;
    const minute = now.getMinutes();
    // Целевые времена: 16:50 и 01:20 (московское время)
    const targets = [
        { h: 16, m: 50 },
        { h: 1, m: 20 },
    ];
    let minDiff = Infinity;
    let next = null;
    for (const t of targets) {
        // Создаем целевое время в московском часовом поясе
        let target = new Date(now);
        // Устанавливаем московское время
        target.setUTCHours(t.h - 3, t.m, 0, 0);
        // Если время уже прошло сегодня, переносим на завтра
        if (target <= now) {
            target.setDate(target.getDate() + 1);
        }
        const diff = target.getTime() - now.getTime();
        if (diff < minDiff) {
            minDiff = diff;
            next = target;
        }
    }
    (0, logger_1.logStats)(`Сейчас (МСК): ${mskHour}:${minute < 10 ? "0" + minute : minute}, следующий запуск через ${Math.round(minDiff / 1000)} сек (${next?.toLocaleTimeString("ru-RU", { timeZone: "Europe/Moscow" })})`);
    return minDiff;
}
const SERVICE_ROLES = [
    "949669576935874570",
    "949669770377179196",
    "949669851440496761",
];
const HONOR_ROLE = "1217444648591687700";
const ACHIEVERS_PATH = path.join(__dirname, "..", "data", "season_achievers.json");
function loadAchievers() {
    if (!fs.existsSync(ACHIEVERS_PATH))
        return new Set();
    try {
        const arr = JSON.parse(fs.readFileSync(ACHIEVERS_PATH, "utf-8"));
        return new Set(arr);
    }
    catch {
        return new Set();
    }
}
function saveAchievers(set) {
    fs.writeFileSync(ACHIEVERS_PATH, JSON.stringify(Array.from(set), null, 2), "utf-8");
}
function clearAchievers() {
    fs.writeFileSync(ACHIEVERS_PATH, "[]", "utf-8");
}
async function updateAchievers(users, members) {
    const achievers = loadAchievers();
    // Сопоставим ник -> userId
    const nickToUserId = new Map();
    for (const [uid, data] of Object.entries(users)) {
        nickToUserId.set((0, normalize_1.normalize)(data.nick), uid);
    }
    for (const m of members) {
        if (m.points >= 1600) {
            const userId = nickToUserId.get((0, normalize_1.normalize)(m.nick));
            if (userId)
                achievers.add(userId);
        }
    }
    saveAchievers(achievers);
    (0, logger_1.logStats)(`Обновлены достижения: ${achievers.size} игроков с 1600+ ЛПР`);
}
async function handleSeasonEndRewards(guild, users) {
    const achievers = loadAchievers();
    (0, logger_1.logReward)(`Начало выдачи наград за сезон. Достигших 1600+ ЛПР: ${achievers.size}`);
    for (const userId of achievers) {
        try {
            const member = await guild.members.fetch(userId);
            if (!member)
                continue;
            // Сколько уже ролей "За безупречную службу"
            const hasRoles = SERVICE_ROLES.filter(rid => member.roles.cache.has(rid));
            // Если есть все 3 — снять их и выдать Орден
            if (hasRoles.length === 3) {
                await member.roles.remove(SERVICE_ROLES, "Замена на Орден Почётного Воина");
                await member.roles.add(HONOR_ROLE, "Выдан Орден Почётного Воина за 3 службы");
                (0, logger_1.logReward)(`${member.user.tag}: сняты все службы, выдан Орден Почётного Воина`);
            }
            else if (hasRoles.length < 3) {
                // Выдать одну из недостающих ролей
                const toGive = SERVICE_ROLES.find(rid => !member.roles.cache.has(rid));
                if (toGive) {
                    await member.roles.add(toGive, "Выдана роль За безупречную службу за 1600+ ЛПР");
                    (0, logger_1.logReward)(`${member.user.tag}: выдана служба (${toGive})`);
                }
            }
        }
        catch (e) {
            (0, logger_1.logReward)(`Не удалось обработать ${userId}`, e);
        }
    }
    clearAchievers();
    (0, logger_1.logReward)("Награды за сезон выданы, файл достижений очищен");
}
async function statsScheduler(client) {
    const startTime = Date.now();
    // Используем московское время (UTC+3)
    const now = new Date();
    const mskHour = now.getUTCHours() + 3;
    const minute = now.getMinutes();
    (0, logger_1.logStats)(`Проверка времени: ${mskHour}:${minute < 10 ? "0" + minute : minute}`);
    if (mskHour === 16 && minute === 50) {
        (0, logger_1.logStats)("Сбор состояния участников (16:50)");
        const members = await (0, clan_1.fetchClanPoints)("ALLIANCE");
        (0, clan_1.saveMembersAtTime)(members, "1650");
        (0, logger_1.logStats)("Сохранено состояние участников (1650)");
        // Получаем информацию о месте полка в лидерборде
        (0, logger_1.logStats)("Получение информации о месте полка в лидерборде...");
        const leaderboardInfo = await (0, leaderboard_1.fetchClanLeaderboardInfo)("ALLIANCE");
        if (leaderboardInfo) {
            const today = new Date().toISOString().slice(0, 10);
            (0, leaderboard_1.saveLeaderboardData)({
                date: today,
                position: leaderboardInfo.position,
                points: leaderboardInfo.points
            });
            (0, logger_1.logStats)(`Сохранена информация о лидерборде: место ${leaderboardInfo.position}, очки ${leaderboardInfo.points}`);
        }
        else {
            (0, logger_1.logStats)("Не удалось получить информацию о лидерборде");
        }
        const users = (0, json_1.loadJson)(constants_1.usersPath);
        await updateAchievers(users, members);
    }
    else if (mskHour === 1 && minute === 20) {
        (0, logger_1.logStats)("Сбор состояния участников и отправка статистики (01:20)");
        const members = await (0, clan_1.fetchClanPoints)("ALLIANCE");
        (0, clan_1.saveMembersAtTime)(members, "0120");
        (0, logger_1.logStats)("Сохранено состояние участников (0120)");
        // Получаем текущую информацию о лидерборде
        (0, logger_1.logStats)("Получение текущей информации о лидерборде...");
        let currentLeaderboardInfo = null;
        try {
            currentLeaderboardInfo = await (0, leaderboard_1.fetchClanLeaderboardInfo)("ALLIANCE");
            if (currentLeaderboardInfo) {
                (0, logger_1.logStats)(`Получена информация о лидерборде: место ${currentLeaderboardInfo.position}, очки ${currentLeaderboardInfo.points}`);
            }
            else {
                (0, logger_1.logStats)("Полк ALLIANCE не найден в лидерборде");
            }
        }
        catch (error) {
            (0, logger_1.logStats)(`Ошибка при получении информации о лидерборде: ${error}`);
        }
        const previousLeaderboardData = (0, leaderboard_1.loadLeaderboardData)();
        // Сравнить и отправить статистику
        const prev = (0, clan_1.loadMembersAtTime)("1650");
        const curr = (0, clan_1.loadMembersAtTime)("0120");
        const prevMap = new Map(prev.map((p) => [(0, normalize_1.normalize)(p.nick), p]));
        const currMap = new Map(curr.map((c) => [(0, normalize_1.normalize)(c.nick), c]));
        let totalDelta = 0;
        const changes = [];
        for (const [nickNorm, currPlayer] of currMap.entries()) {
            const prevPlayer = prevMap.get(nickNorm);
            if (prevPlayer) {
                const delta = currPlayer.points - prevPlayer.points;
                if (delta !== 0) {
                    changes.push({ nick: currPlayer.nick, delta });
                    totalDelta += delta;
                }
            }
        }
        let msg = `\uD83D\uDCCA **Статистика за сутки:**\n`;
        // Добавляем информацию о лидерборде
        if (currentLeaderboardInfo && previousLeaderboardData) {
            const comparison = (0, leaderboard_1.compareLeaderboardData)(currentLeaderboardInfo, previousLeaderboardData);
            msg += `🏆 **Место в лидерборде:** ${currentLeaderboardInfo.position}\n`;
            if (comparison.positionDirection === "up") {
                msg += `📈 Поднялись на ${comparison.positionChange} мест\n`;
            }
            else if (comparison.positionDirection === "down") {
                msg += `📉 Опустились на ${comparison.positionChange} мест\n`;
            }
            else {
                msg += `➡️ Место не изменилось\n`;
            }
            msg += `💎 **Очки полка:** ${currentLeaderboardInfo.points.toLocaleString()}\n`;
            if (comparison.pointsDirection === "up") {
                msg += `📈 Получили ${comparison.pointsChange.toLocaleString()} очков\n`;
            }
            else if (comparison.pointsDirection === "down") {
                msg += `📉 Потеряли ${comparison.pointsChange.toLocaleString()} очков\n`;
            }
            else {
                msg += `➡️ Очки не изменились\n`;
            }
            msg += `\n`;
        }
        else if (currentLeaderboardInfo) {
            msg += `🏆 **Место в лидерборде:** ${currentLeaderboardInfo.position}\n`;
            msg += `💎 **Очки полка:** ${currentLeaderboardInfo.points.toLocaleString()}\n\n`;
        }
        msg += `Полк всего: ${totalDelta >= 0 ? "+" : ""}${totalDelta} очков\n`;
        if (changes.length > 0) {
            msg += `\nИзменения по игрокам:\n`;
            for (const { nick, delta } of changes.sort((a, b) => b.delta - a.delta)) {
                msg += `• ${nick}: ${delta >= 0 ? "+" : ""}${delta}\n`;
            }
        }
        else {
            msg += `\nЗа сутки не было изменений очков ни у одного игрока.\n`;
        }
        const channel = await client.channels.fetch(constants_1.STATS_CHANNEL_ID);
        if (channel && channel.isTextBased()) {
            await channel.send(msg);
            (0, logger_1.logStats)("Статистика отправлена в канал");
        }
        // Проверка конца сезона: все points = 0
        if (curr.every(p => p.points === 0)) {
            (0, logger_1.logStats)("Обнаружен конец сезона (все очки = 0), запуск выдачи наград");
            const users = (0, json_1.loadJson)(constants_1.usersPath);
            const guild = client.guilds.cache.first();
            if (guild) {
                await handleSeasonEndRewards(guild, users);
            }
        }
    }
    else {
        (0, logger_1.logStats)("Сейчас не время сбора статистики");
    }
    (0, resources_1.trackFunctionPerformance)('statsScheduler', startTime);
    setTimeout(() => statsScheduler(client), getNextStatsDelayMs());
}
function getNextSyncclanDelayMs() {
    const now = new Date();
    const mskHour = now.getUTCHours() + 3;
    const minute = now.getMinutes();
    const second = now.getSeconds();
    // Целевое время: 12:00 (московское время)
    const targetHour = 12;
    const targetMinute = 0;
    let target = new Date(now);
    // Устанавливаем московское время
    target.setUTCHours(targetHour - 3, targetMinute, 0, 0);
    // Если сегодня 12:00 уже прошло, ждем до завтра
    if (target <= now) {
        target.setDate(target.getDate() + 1);
    }
    const diff = target.getTime() - now.getTime();
    (0, logger_1.logSyncclan)(`Сейчас (МСК): ${mskHour}:${minute < 10 ? "0" + minute : minute}, следующий запуск через ${Math.round(diff / 1000)} сек (${target.toLocaleTimeString("ru-RU", { timeZone: "Europe/Moscow" })})`);
    return diff;
}
async function syncclanScheduler(client) {
    const startTime = Date.now();
    const now = new Date();
    const mskHour = now.getUTCHours() + 3;
    const minute = now.getMinutes();
    (0, logger_1.logSyncclan)(`Проверка времени: ${mskHour}:${minute < 10 ? "0" + minute : minute}`);
    if (mskHour === 12 && minute === 0) {
        (0, logger_1.logSyncclan)("Автоматический запуск синхронизации клана ALLIANCE");
        try {
            // Имитируем выполнение команды syncclan ALLIANCE
            const users = (0, json_1.loadJson)(constants_1.usersPath);
            const tracked = (0, json_1.loadJson)(constants_1.trackedPath);
            const members = await (0, clan_1.fetchClanPoints)("ALLIANCE");
            // 1. Загрузить отслеживаемых участников и найти покинувших
            const trackedMembers = (0, clan_1.loadLeaversTracking)();
            // Если файл отслеживания пустой, инициализируем его текущими участниками
            if (trackedMembers.length === 0) {
                (0, logger_1.logSyncclan)("Инициализация файла отслеживания покинувших игроков");
                (0, clan_1.saveLeaversTracking)(members);
                (0, logger_1.logSyncclan)(`Файл отслеживания инициализирован с ${members.length} участниками клана ALLIANCE`);
            }
            else {
                const leavers = (0, clan_1.findLeaversFromTracking)(members);
                (0, logger_1.logSyncclan)(`trackedMembers: ${trackedMembers.map(m => m.nick)}`);
                (0, logger_1.logSyncclan)(`currentMembers: ${members.map(m => m.nick)}`);
                (0, logger_1.logSyncclan)(`leavers: ${leavers.map(m => m.nick)}`);
                if (leavers.length > 0) {
                    const channel = await client.channels.fetch("882263905009807390");
                    const date = new Date().toLocaleDateString("ru-RU");
                    for (const leaver of leavers) {
                        const msg = `${leaver.nick} покинул полк ${date} с ${leaver.points} лпр`;
                        if (channel && channel.isTextBased()) {
                            await channel.send(msg);
                        }
                    }
                    (0, logger_1.logSyncclan)(`Отправлено уведомлений о покинувших: ${leavers.length}`);
                }
                // 2. Обновить файл отслеживания текущими участниками
                (0, clan_1.saveLeaversTracking)(members);
            }
            // 3. Сохранить новые данные в следующий файл (для статистики)
            (0, clan_1.saveMembersAlternating)(members);
            let count = 0;
            for (const m of members) {
                const uid = Object.keys(users).find((id) => (0, normalize_1.normalize)(users[id].nick ?? "") === (0, normalize_1.normalize)(m.nick));
                if (uid) {
                    users[uid].points = m.points;
                    count++;
                }
                const trackedKey = Object.keys(tracked).find((t) => (0, normalize_1.normalize)(t) === (0, normalize_1.normalize)(m.nick));
                if (trackedKey) {
                    tracked[trackedKey].lastPoints = m.points;
                    count++;
                }
            }
            (0, json_1.saveJson)(constants_1.usersPath, users);
            (0, json_1.saveJson)(constants_1.trackedPath, tracked);
            (0, logger_1.logSyncclan)(`Синхронизировано ${count} участников по клану ALLIANCE`);
        }
        catch (error) {
            (0, logger_1.logSyncclan)(`Ошибка при автоматической синхронизации: ${error.message}`);
        }
    }
    else {
        (0, logger_1.logSyncclan)("Сейчас не время синхронизации клана");
    }
    (0, resources_1.trackFunctionPerformance)('syncclanScheduler', startTime);
    setTimeout(() => syncclanScheduler(client), getNextSyncclanDelayMs());
}
client.once("ready", async () => {
    const guild = client.guilds.cache.first();
    if (!guild)
        return;
    (0, logger_1.info)(`Бот запущен. Пользователь: ${client.user?.tag}`);
    for (const channelId of constants_1.VOICE_CHANNEL_IDS) {
        const channel = await guild.channels.fetch(channelId);
        if (channel?.isVoiceBased()) {
            const realCount = Array.from(channel.members.values()).filter((m) => !m.user.bot).length;
            voiceCounts.set(channelId, realCount);
            (0, logger_1.logVoiceState)(`Канал "${channel.name}" загружен: ${realCount} человек(а)`);
        }
    }
    (0, logger_1.info)("Бот готов, голосовые каналы загружены");
    // Очистка старых логов при запуске
    (0, logger_1.cleanupOldLogs)();
    (0, pbNotify_1.pbNotifyScheduler)(client);
    (0, pbNotify_1.autoPbAnnounceScheduler)(client);
    statsScheduler(client);
    syncclanScheduler(client);
});
client.on("guildMemberAdd", (member) => {
    const users = (0, json_1.loadJson)(constants_1.usersPath);
    if (!users[member.id]) {
        users[member.id] = {
            joinDate: new Date().toISOString(),
            points: 0,
            wasWarned: false,
            nick: member.user.username,
        };
        (0, json_1.saveJson)(constants_1.usersPath, users);
        (0, logger_1.info)(`Зарегистрирован новый участник: ${member.user.tag}`);
    }
});
process.on("unhandledRejection", (reason, promise) => {
    (0, logger_1.error)("Необработанное отклонение промиса", { reason, promise });
});
process.on("uncaughtException", (err) => {
    (0, logger_1.error)("Необработанное исключение", err);
});
