"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addtracerCommand = addtracerCommand;
const json_1 = require("../utils/json");
const constants_1 = require("../constants");
async function addtracerCommand(interaction) {
    const nick = interaction.options.getString("nickname", true);
    const tracked = (0, json_1.loadJson)(constants_1.trackedPath);
    if (tracked[nick]) {
        await interaction.reply(`⚠️ Игрок ${nick} уже отслеживается.`);
        return;
    }
    tracked[nick] = {
        trackedSince: new Date().toISOString(),
        assignedBy: interaction.user.id,
        warnedAfter7d: false,
        warnedAfter14d: false,
        lastPoints: 0,
    };
    (0, json_1.saveJson)(constants_1.trackedPath, tracked);
    await interaction.reply(`🔍 Начато отслеживание игрока ${nick}`);
}
