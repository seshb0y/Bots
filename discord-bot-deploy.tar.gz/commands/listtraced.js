"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listtracedCommand = listtracedCommand;
const json_1 = require("../utils/json");
const constants_1 = require("../constants");
const clan_1 = require("../utils/clan");
const normalize_1 = require("../utils/normalize");
async function listtracedCommand(interaction) {
    // Сначала синхронизируем очки по клану ALLIANCE
    const users = (0, json_1.loadJson)(constants_1.usersPath);
    const tracked = (0, json_1.loadJson)(constants_1.trackedPath);
    const members = await (0, clan_1.fetchClanPoints)("ALLIANCE");
    let count = 0;
    for (const m of members) {
        const uid = Object.keys(users).find((id) => (0, normalize_1.normalize)(users[id].nick ?? "") === (0, normalize_1.normalize)(m.nick));
        if (uid) {
            users[uid].points = m.points;
            count++;
        }
        const trackedKey = Object.keys(tracked).find((t) => (0, normalize_1.normalize)(t) === (0, normalize_1.normalize)(m.nick));
        if (trackedKey) {
            tracked[trackedKey].lastPoints = m.points;
            count++;
        }
    }
    (0, json_1.saveJson)(constants_1.usersPath, users);
    (0, json_1.saveJson)(constants_1.trackedPath, tracked);
    // Далее — стандартный вывод списка
    if (Object.keys(tracked).length === 0) {
        await interaction.reply("📭 Сейчас никто не отслеживается.");
        return;
    }
    let reply = `📋 **Список отслеживаемых игроков:**\n`;
    for (const [nick, data] of Object.entries(tracked)) {
        const days = Math.floor((Date.now() - new Date(data.trackedSince).getTime()) /
            (1000 * 60 * 60 * 24));
        reply += `• **${nick}** — ${data.lastPoints} очков, отслеживается ${days} дн.\n`;
    }
    await interaction.reply(reply);
}
