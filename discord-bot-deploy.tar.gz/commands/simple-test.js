"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.simpleTestCommand = simpleTestCommand;
async function simpleTestCommand(interaction) {
    console.log("🔍 Простая тестовая команда вызвана");
    try {
        await interaction.reply({ content: "✅ Простая команда работает!", ephemeral: true });
        console.log("🔍 Простая команда выполнена успешно");
    }
    catch (error) {
        console.error("❌ Ошибка в простой команде:", error);
        await interaction.reply({ content: "❌ Ошибка в простой команде", ephemeral: true });
    }
}
