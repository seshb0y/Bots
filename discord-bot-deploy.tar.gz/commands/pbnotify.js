"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pbnotifyCommand = pbnotifyCommand;
const pbNotify_1 = require("../utils/pbNotify");
async function pbnotifyCommand(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    await (0, pbNotify_1.askOfficersForPb)(client);
    await interaction.editReply("PB notification sent to all officers (manual test).");
}
