"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removetracerCommand = removetracerCommand;
const json_1 = require("../utils/json");
const constants_1 = require("../constants");
const normalize_1 = require("../utils/normalize");
async function removetracerCommand(interaction) {
    const nick = interaction.options.getString("nickname", true);
    const tracked = (0, json_1.loadJson)(constants_1.trackedPath);
    const trackedKey = Object.keys(tracked).find((t) => (0, normalize_1.normalize)(t) === (0, normalize_1.normalize)(nick));
    if (!trackedKey) {
        await interaction.reply(`❌ Игрок ${nick} не найден в списке отслеживаемых.`);
        return;
    }
    delete tracked[trackedKey];
    (0, json_1.saveJson)(constants_1.trackedPath, tracked);
    await interaction.reply(`✅ Игрок ${trackedKey} удалён из отслеживания.`);
}
