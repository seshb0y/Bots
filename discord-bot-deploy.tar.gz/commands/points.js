"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pointsCommand = pointsCommand;
const json_1 = require("../utils/json");
const constants_1 = require("../constants");
async function pointsCommand(interaction) {
    const users = (0, json_1.loadJson)(constants_1.usersPath);
    const userId = interaction.user.id;
    const points = users[userId]?.points ?? 0;
    await interaction.reply(`У тебя ${points} полковых очков.`);
}
