"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.syncclanCommand = syncclanCommand;
const json_1 = require("../utils/json");
const constants_1 = require("../constants");
const clan_1 = require("../utils/clan");
const normalize_1 = require("../utils/normalize");
const logger_1 = require("../utils/logger");
const LEAVE_CHANNEL_ID = "882263905009807390";
async function syncclanCommand(interaction) {
    await interaction.deferReply({ ephemeral: true });
    const clanTag = interaction.options.getString("clan", true);
    (0, logger_1.logSyncclan)(`Запуск синхронизации клана ${clanTag}`, {
        userId: interaction.user.id,
        username: interaction.user.tag
    });
    const users = (0, json_1.loadJson)(constants_1.usersPath);
    const tracked = (0, json_1.loadJson)(constants_1.trackedPath);
    const members = await (0, clan_1.fetchClanPoints)(clanTag);
    // 1. Загрузить отслеживаемых участников и найти покинувших
    const trackedMembers = (0, clan_1.loadLeaversTracking)();
    // Если файл отслеживания пустой, инициализируем его текущими участниками
    if (trackedMembers.length === 0) {
        (0, logger_1.logSyncclan)("Инициализация файла отслеживания покинувших игроков");
        (0, clan_1.saveLeaversTracking)(members);
        (0, logger_1.logSyncclan)(`Файл отслеживания инициализирован с ${members.length} участниками клана ${clanTag}`);
        await interaction.editReply(`✅ Файл отслеживания инициализирован с ${members.length} участниками клана ${clanTag}.`);
        return;
    }
    const leavers = (0, clan_1.findLeaversFromTracking)(members);
    (0, logger_1.logSyncclan)(`trackedMembers: ${trackedMembers.map(m => m.nick)}`);
    (0, logger_1.logSyncclan)(`currentMembers: ${members.map(m => m.nick)}`);
    (0, logger_1.logSyncclan)(`leavers: ${leavers.map(m => m.nick)}`);
    if (leavers.length > 0) {
        const channel = await interaction.client.channels.fetch(LEAVE_CHANNEL_ID);
        const date = new Date().toLocaleDateString("ru-RU");
        for (const leaver of leavers) {
            const msg = `${leaver.nick} покинул полк ${date} с ${leaver.points} лпр`;
            if (channel && channel.isTextBased()) {
                await channel.send(msg);
            }
        }
        (0, logger_1.logSyncclan)(`Отправлено уведомлений о покинувших: ${leavers.length}`);
    }
    // 2. Обновить файл отслеживания текущими участниками
    (0, clan_1.saveLeaversTracking)(members);
    // 3. Сохранить новые данные в следующий файл (для статистики)
    (0, clan_1.saveMembersAlternating)(members);
    let count = 0;
    for (const m of members) {
        const uid = Object.keys(users).find((id) => (0, normalize_1.normalize)(users[id].nick ?? "") === (0, normalize_1.normalize)(m.nick));
        if (uid) {
            users[uid].points = m.points;
            count++;
        }
        const trackedKey = Object.keys(tracked).find((t) => (0, normalize_1.normalize)(t) === (0, normalize_1.normalize)(m.nick));
        if (trackedKey) {
            tracked[trackedKey].lastPoints = m.points;
            count++;
        }
    }
    (0, json_1.saveJson)(constants_1.usersPath, users);
    (0, json_1.saveJson)(constants_1.trackedPath, tracked);
    (0, logger_1.logSyncclan)(`Синхронизировано ${count} участников по клану ${clanTag}`);
    await interaction.editReply(`✅ Синхронизировано ${count} участников по клану ${clanTag}.`);
}
