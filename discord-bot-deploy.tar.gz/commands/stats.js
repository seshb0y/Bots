"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.statsCommand = statsCommand;
const constants_1 = require("../constants");
const clan_1 = require("../utils/clan");
const normalize_1 = require("../utils/normalize");
const leaderboard_1 = require("../utils/leaderboard");
async function statsCommand(interaction) {
    await interaction.deferReply({ ephemeral: true });
    // Получаем информацию о лидерборде
    const currentLeaderboardInfo = await (0, leaderboard_1.fetchClanLeaderboardInfo)("ALLIANCE");
    const previousLeaderboardData = (0, leaderboard_1.loadLeaderboardData)();
    const prev = (0, clan_1.loadMembersAtTime)("1650");
    const curr = (0, clan_1.loadMembersAtTime)("0120");
    // Сопоставим по нормализованному нику
    const prevMap = new Map();
    for (const p of prev)
        prevMap.set((0, normalize_1.normalize)(p.nick), p);
    const currMap = new Map();
    for (const c of curr)
        currMap.set((0, normalize_1.normalize)(c.nick), c);
    let totalDelta = 0;
    const changes = [];
    for (const [nickNorm, currPlayer] of currMap.entries()) {
        const prevPlayer = prevMap.get(nickNorm);
        if (prevPlayer) {
            const delta = currPlayer.points - prevPlayer.points;
            if (delta !== 0) {
                changes.push({ nick: currPlayer.nick, delta });
                totalDelta += delta;
            }
        }
    }
    let msg = `\uD83D\uDCCA **Статистика за сутки:**\n`;
    // Добавляем информацию о лидерборде
    if (currentLeaderboardInfo && previousLeaderboardData) {
        const comparison = (0, leaderboard_1.compareLeaderboardData)(currentLeaderboardInfo, previousLeaderboardData);
        msg += `🏆 **Место в лидерборде:** ${currentLeaderboardInfo.position}\n`;
        if (comparison.positionDirection === "up") {
            msg += `📈 Поднялись на ${comparison.positionChange} мест\n`;
        }
        else if (comparison.positionDirection === "down") {
            msg += `📉 Опустились на ${comparison.positionChange} мест\n`;
        }
        else {
            msg += `➡️ Место не изменилось\n`;
        }
        msg += `💎 **Очки полка:** ${currentLeaderboardInfo.points}\n`;
        if (comparison.pointsDirection === "up") {
            msg += `📈 Получили ${comparison.pointsChange} очков\n`;
        }
        else if (comparison.pointsDirection === "down") {
            msg += `📉 Потеряли ${comparison.pointsChange} очков\n`;
        }
        else {
            msg += `➡️ Очки не изменились\n`;
        }
        msg += `\n`;
    }
    else if (currentLeaderboardInfo) {
        msg += `🏆 **Место в лидерборде:** ${currentLeaderboardInfo.position}\n`;
        msg += `💎 **Очки полка:** ${currentLeaderboardInfo.points}\n\n`;
    }
    msg += `Полк всего: ${totalDelta >= 0 ? "+" : ""}${totalDelta} очков\n`;
    if (changes.length > 0) {
        msg += `\nИзменения по игрокам:\n`;
        for (const { nick, delta } of changes.sort((a, b) => b.delta - a.delta)) {
            msg += `• ${nick}: ${delta >= 0 ? "+" : ""}${delta}\n`;
        }
    }
    else {
        msg += `\nЗа сутки не было изменений очков ни у одного игрока.\n`;
    }
    // Отправляем в канал статистики
    const channel = await interaction.client.channels.fetch(constants_1.STATS_CHANNEL_ID);
    if (channel && channel.isTextBased()) {
        await channel.send(msg);
        await interaction.editReply("Статистика отправлена в канал.");
    }
    else {
        await interaction.editReply("Не удалось найти текстовый канал для статистики.");
    }
}
