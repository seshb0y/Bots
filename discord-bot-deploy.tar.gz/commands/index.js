"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.teststatsCommand = exports.resettleaversCommand = exports.syncclanCommand = exports.resourcesCommand = exports.pbnotifyCommand = exports.listtracedCommand = exports.removetracerCommand = exports.addtracerCommand = exports.pointsCommand = exports.helpCommand = void 0;
exports.setupCommands = setupCommands;
const help_1 = require("./help");
Object.defineProperty(exports, "helpCommand", { enumerable: true, get: function () { return help_1.helpCommand; } });
const points_1 = require("./points");
Object.defineProperty(exports, "pointsCommand", { enumerable: true, get: function () { return points_1.pointsCommand; } });
const addtracer_1 = require("./addtracer");
Object.defineProperty(exports, "addtracerCommand", { enumerable: true, get: function () { return addtracer_1.addtracerCommand; } });
const removetracer_1 = require("./removetracer");
Object.defineProperty(exports, "removetracerCommand", { enumerable: true, get: function () { return removetracer_1.removetracerCommand; } });
const listtraced_1 = require("./listtraced");
Object.defineProperty(exports, "listtracedCommand", { enumerable: true, get: function () { return listtraced_1.listtracedCommand; } });
const pbnotify_1 = require("./pbnotify");
Object.defineProperty(exports, "pbnotifyCommand", { enumerable: true, get: function () { return pbnotify_1.pbnotifyCommand; } });
const resources_1 = require("./resources");
Object.defineProperty(exports, "resourcesCommand", { enumerable: true, get: function () { return resources_1.resourcesCommand; } });
const syncclan_1 = require("./syncclan");
Object.defineProperty(exports, "syncclanCommand", { enumerable: true, get: function () { return syncclan_1.syncclanCommand; } });
const resettleavers_1 = require("./resettleavers");
Object.defineProperty(exports, "resettleaversCommand", { enumerable: true, get: function () { return resettleavers_1.resettleaversCommand; } });
const teststats_1 = require("./teststats");
Object.defineProperty(exports, "teststatsCommand", { enumerable: true, get: function () { return teststats_1.teststatsCommand; } });
const simple_test_1 = require("./simple-test");
const pbNotify_1 = require("../utils/pbNotify");
const logger_1 = require("../utils/logger");
function setupCommands(client) {
    client.on("interactionCreate", async (interaction) => {
        try {
            // --- обработка кнопок ---
            if (interaction.isButton()) {
                if (interaction.customId === "pb_yes") {
                    (0, logger_1.logInteraction)("Нажата кнопка 'Собираю' для ПБ", { userId: interaction.user.id, username: interaction.user.tag });
                    const guild = interaction.guild || client.guilds.cache.first();
                    const channelIds = [
                        "763085196118851608",
                        "885928590720524328",
                        "821082995188170783"
                    ];
                    // Проверяем количество людей в каждом канале отдельно
                    let totalCount = 0;
                    let mainChannelCount = 0; // Количество людей в канале 763085196118851608
                    for (const id of channelIds) {
                        const channel = await guild?.channels.fetch(id);
                        if (channel?.isVoiceBased()) {
                            const channelCount = Array.from(channel.members.values()).filter(m => !m.user.bot).length;
                            totalCount += channelCount;
                            // Отдельно считаем людей в основном канале
                            if (id === "763085196118851608") {
                                mainChannelCount = channelCount;
                            }
                        }
                    }
                    const plus = Math.max(0, 8 - totalCount);
                    // Проверяем, есть ли люди в основном канале
                    if (mainChannelCount === 0) {
                        await interaction.reply({
                            content: "❌ В основном канале нет людей! Сначала зайдите в канал для ПБ.",
                            ephemeral: true
                        });
                        return;
                    }
                    const announceChannel = await client.channels.fetch("763085196118851607");
                    if (announceChannel && announceChannel.isTextBased()) {
                        const now = new Date();
                        const time = now.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
                        const embed = {
                            color: 0x2ecc71,
                            title: `🚩 Сбор на ПБ!`,
                            description: `@everyone\n\n` +
                                `**+${plus}** игроков нужно для ПБ\n` +
                                `\n` +
                                `👤 **Собирает:** ${interaction.user} \n` +
                                `🕒 **Время:** ${time}`,
                            footer: {
                                text: "Желаем удачи в бою!"
                            }
                        };
                        await announceChannel.send({ embeds: [embed] });
                        // Отмечаем, что ПБ объявлен сегодня
                        const today = new Date().toISOString().slice(0, 10);
                        (0, pbNotify_1.setPbAnnounced)(true, interaction.user.id, today);
                        (0, logger_1.logInteraction)("Отправлено объявление о ПБ в канал", {
                            channelId: "763085196118851607",
                            plus,
                            collector: interaction.user.tag
                        });
                    }
                    await interaction.reply({ content: "Оповещение о сборе ПБ отправлено в канал!", ephemeral: true });
                    return;
                }
            }
            // --- обработка команд ---
            if (interaction.isChatInputCommand()) {
                const commandName = interaction.commandName;
                (0, logger_1.logCommand)(`Выполняется команда: ${commandName}`, {
                    userId: interaction.user.id,
                    username: interaction.user.tag,
                    guildId: interaction.guildId
                });
                switch (commandName) {
                    case "help":
                        await (0, help_1.helpCommand)(interaction);
                        break;
                    case "points":
                        await (0, points_1.pointsCommand)(interaction);
                        break;
                    case "addtracer":
                        await (0, addtracer_1.addtracerCommand)(interaction);
                        break;
                    case "removetracer":
                        await (0, removetracer_1.removetracerCommand)(interaction);
                        break;
                    case "listtraced":
                        await (0, listtraced_1.listtracedCommand)(interaction);
                        break;
                    case "pbnotify":
                        await (0, pbnotify_1.pbnotifyCommand)(interaction, client);
                        break;
                    case "resources":
                        await (0, resources_1.resourcesCommand)(interaction);
                        break;
                    case "syncclan":
                        await (0, syncclan_1.syncclanCommand)(interaction);
                        break;
                    case "resettleavers":
                        await (0, resettleavers_1.resettleaversCommand)(interaction);
                        break;
                    case "teststats":
                        await (0, teststats_1.teststatsCommand)(interaction);
                        break;
                    case "ping":
                        await interaction.reply({ content: "🏓 Понг! Бот работает.", ephemeral: true });
                        break;
                    case "simpletest":
                        await (0, simple_test_1.simpleTestCommand)(interaction);
                        break;
                    default:
                        (0, logger_1.logCommand)(`Неизвестная команда: ${commandName}`, {
                            userId: interaction.user.id,
                            username: interaction.user.tag
                        });
                        await interaction.reply({ content: "Неизвестная команда!", ephemeral: true });
                }
            }
        }
        catch (err) {
            (0, logger_1.error)("Ошибка при обработке взаимодействия", err);
            try {
                const reply = {
                    content: "Произошла ошибка при выполнении команды!",
                    ephemeral: true,
                };
                if (interaction.isChatInputCommand()) {
                    if (interaction.deferred || interaction.replied) {
                        await interaction.editReply(reply);
                    }
                    else {
                        await interaction.reply(reply);
                    }
                }
                else if (interaction.isButton()) {
                    await interaction.reply(reply);
                }
            }
            catch (replyError) {
                (0, logger_1.error)("Не удалось отправить сообщение об ошибке", replyError);
            }
        }
    });
}
